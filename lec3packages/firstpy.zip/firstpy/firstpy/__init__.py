#!/usr/bin/env python
"""Template for the __init__ file in a python package."""
__all__ = ['tests']

def some_function(arg):
    return 1
